rootProject.name = "Coin500"
include(":app")
